/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.modul.pojo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ronal
 */
@Entity
@Table(name = "inv_clswarehouse", catalog = "sidb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InvClswarehouse.findAll", query = "SELECT i FROM InvClswarehouse i")
    , @NamedQuery(name = "InvClswarehouse.findByInvidWarehs", query = "SELECT i FROM InvClswarehouse i WHERE i.invidWarehs = :invidWarehs")
    , @NamedQuery(name = "InvClswarehouse.findByInvcodeWarehs", query = "SELECT i FROM InvClswarehouse i WHERE i.invcodeWarehs = :invcodeWarehs")
    , @NamedQuery(name = "InvClswarehouse.findByInvnameWarehs", query = "SELECT i FROM InvClswarehouse i WHERE i.invnameWarehs = :invnameWarehs")
    , @NamedQuery(name = "InvClswarehouse.findByInvlocationWarehs", query = "SELECT i FROM InvClswarehouse i WHERE i.invlocationWarehs = :invlocationWarehs")
    , @NamedQuery(name = "InvClswarehouse.findByInvinputUser", query = "SELECT i FROM InvClswarehouse i WHERE i.invinputUser = :invinputUser")
    , @NamedQuery(name = "InvClswarehouse.findByInvinputDate", query = "SELECT i FROM InvClswarehouse i WHERE i.invinputDate = :invinputDate")})
public class InvClswarehouse implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "inv_idWarehs")
    private Integer invidWarehs;
    @Size(max = 120)
    @Column(name = "inv_codeWarehs")
    private String invcodeWarehs;
    @Size(max = 120)
    @Column(name = "inv_nameWarehs")
    private String invnameWarehs;
    @Size(max = 120)
    @Column(name = "inv_locationWarehs")
    private String invlocationWarehs;
    @Size(max = 120)
    @Column(name = "inv_inputUser")
    private String invinputUser;
    @Column(name = "inv_inputDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date invinputDate;
    @JoinColumn(name = "inv_statusWarehs", referencedColumnName = "core_idstatus")
    @ManyToOne(fetch = FetchType.EAGER)
    private CoreStatusrecord invstatusWarehs;

    public InvClswarehouse() {
    }

    public InvClswarehouse(Integer invidWarehs) {
        this.invidWarehs = invidWarehs;
    }

    public Integer getInvidWarehs() {
        return invidWarehs;
    }

    public void setInvidWarehs(Integer invidWarehs) {
        this.invidWarehs = invidWarehs;
    }

    public String getInvcodeWarehs() {
        return invcodeWarehs;
    }

    public void setInvcodeWarehs(String invcodeWarehs) {
        this.invcodeWarehs = invcodeWarehs;
    }

    public String getInvnameWarehs() {
        return invnameWarehs;
    }

    public void setInvnameWarehs(String invnameWarehs) {
        this.invnameWarehs = invnameWarehs;
    }

    public String getInvlocationWarehs() {
        return invlocationWarehs;
    }

    public void setInvlocationWarehs(String invlocationWarehs) {
        this.invlocationWarehs = invlocationWarehs;
    }

    public String getInvinputUser() {
        return invinputUser;
    }

    public void setInvinputUser(String invinputUser) {
        this.invinputUser = invinputUser;
    }

    public Date getInvinputDate() {
        return invinputDate;
    }

    public void setInvinputDate(Date invinputDate) {
        this.invinputDate = invinputDate;
    }

    public CoreStatusrecord getInvstatusWarehs() {
        return invstatusWarehs;
    }

    public void setInvstatusWarehs(CoreStatusrecord invstatusWarehs) {
        this.invstatusWarehs = invstatusWarehs;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (invidWarehs != null ? invidWarehs.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof InvClswarehouse)) {
            return false;
        }
        InvClswarehouse other = (InvClswarehouse) object;
        if ((this.invidWarehs == null && other.invidWarehs != null) || (this.invidWarehs != null && !this.invidWarehs.equals(other.invidWarehs))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "inventory.modul.pojo.InvClswarehouse[ invidWarehs=" + invidWarehs + " ]";
    }
    
}
