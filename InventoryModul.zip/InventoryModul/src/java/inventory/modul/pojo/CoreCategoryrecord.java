/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.modul.pojo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ronal
 */
@Entity
@Table(name = "core_categoryrecord", catalog = "sidb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CoreCategoryrecord.findAll", query = "SELECT c FROM CoreCategoryrecord c")
    , @NamedQuery(name = "CoreCategoryrecord.findByCoreidCategory", query = "SELECT c FROM CoreCategoryrecord c WHERE c.coreidCategory = :coreidCategory")
    , @NamedQuery(name = "CoreCategoryrecord.findByCorenameCategory", query = "SELECT c FROM CoreCategoryrecord c WHERE c.corenameCategory = :corenameCategory")
    , @NamedQuery(name = "CoreCategoryrecord.findByCoredescCategory", query = "SELECT c FROM CoreCategoryrecord c WHERE c.coredescCategory = :coredescCategory")
    , @NamedQuery(name = "CoreCategoryrecord.findByCoreinputUser", query = "SELECT c FROM CoreCategoryrecord c WHERE c.coreinputUser = :coreinputUser")
    , @NamedQuery(name = "CoreCategoryrecord.findByCoreinputDate", query = "SELECT c FROM CoreCategoryrecord c WHERE c.coreinputDate = :coreinputDate")})
public class CoreCategoryrecord implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "core_idCategory")
    private Integer coreidCategory;
    @Size(max = 120)
    @Column(name = "core_nameCategory")
    private String corenameCategory;
    @Size(max = 120)
    @Column(name = "core_descCategory")
    private String coredescCategory;
    @Size(max = 120)
    @Column(name = "core_inputUser")
    private String coreinputUser;
    @Column(name = "core_inputDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date coreinputDate;
    @JoinColumn(name = "core_statusCategory", referencedColumnName = "core_idstatus")
    @ManyToOne(fetch = FetchType.EAGER)
    private CoreStatusrecord corestatusCategory;

    public CoreCategoryrecord() {
    }

    public CoreCategoryrecord(Integer coreidCategory) {
        this.coreidCategory = coreidCategory;
    }

    public Integer getCoreidCategory() {
        return coreidCategory;
    }

    public void setCoreidCategory(Integer coreidCategory) {
        this.coreidCategory = coreidCategory;
    }

    public String getCorenameCategory() {
        return corenameCategory;
    }

    public void setCorenameCategory(String corenameCategory) {
        this.corenameCategory = corenameCategory;
    }

    public String getCoredescCategory() {
        return coredescCategory;
    }

    public void setCoredescCategory(String coredescCategory) {
        this.coredescCategory = coredescCategory;
    }

    public String getCoreinputUser() {
        return coreinputUser;
    }

    public void setCoreinputUser(String coreinputUser) {
        this.coreinputUser = coreinputUser;
    }

    public Date getCoreinputDate() {
        return coreinputDate;
    }

    public void setCoreinputDate(Date coreinputDate) {
        this.coreinputDate = coreinputDate;
    }

    public CoreStatusrecord getCorestatusCategory() {
        return corestatusCategory;
    }

    public void setCorestatusCategory(CoreStatusrecord corestatusCategory) {
        this.corestatusCategory = corestatusCategory;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (coreidCategory != null ? coreidCategory.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CoreCategoryrecord)) {
            return false;
        }
        CoreCategoryrecord other = (CoreCategoryrecord) object;
        if ((this.coreidCategory == null && other.coreidCategory != null) || (this.coreidCategory != null && !this.coreidCategory.equals(other.coreidCategory))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "inventory.modul.pojo.CoreCategoryrecord[ coreidCategory=" + coreidCategory + " ]";
    }
    
}
