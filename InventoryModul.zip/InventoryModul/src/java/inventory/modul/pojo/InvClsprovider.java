/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.modul.pojo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ronal
 */
@Entity
@Table(name = "inv_clsprovider", catalog = "sidb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InvClsprovider.findAll", query = "SELECT i FROM InvClsprovider i")
    , @NamedQuery(name = "InvClsprovider.findByInvidProv", query = "SELECT i FROM InvClsprovider i WHERE i.invidProv = :invidProv")
    , @NamedQuery(name = "InvClsprovider.findByInvnameProv", query = "SELECT i FROM InvClsprovider i WHERE i.invnameProv = :invnameProv")
    , @NamedQuery(name = "InvClsprovider.findByInvdescProv", query = "SELECT i FROM InvClsprovider i WHERE i.invdescProv = :invdescProv")
    , @NamedQuery(name = "InvClsprovider.findByInvinputUser", query = "SELECT i FROM InvClsprovider i WHERE i.invinputUser = :invinputUser")
    , @NamedQuery(name = "InvClsprovider.findByInvinputDate", query = "SELECT i FROM InvClsprovider i WHERE i.invinputDate = :invinputDate")})
public class InvClsprovider implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "inv_idProv")
    private Integer invidProv;
    @Size(max = 120)
    @Column(name = "inv_nameProv")
    private String invnameProv;
    @Size(max = 120)
    @Column(name = "inv_descProv")
    private String invdescProv;
    @Size(max = 120)
    @Column(name = "inv_inputUser")
    private String invinputUser;
    @Column(name = "inv_inputDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date invinputDate;
    @JoinColumn(name = "inv_statusProv", referencedColumnName = "core_idstatus")
    @ManyToOne(fetch = FetchType.EAGER)
    private CoreStatusrecord invstatusProv;

    public InvClsprovider() {
    }

    public InvClsprovider(Integer invidProv) {
        this.invidProv = invidProv;
    }

    public Integer getInvidProv() {
        return invidProv;
    }

    public void setInvidProv(Integer invidProv) {
        this.invidProv = invidProv;
    }

    public String getInvnameProv() {
        return invnameProv;
    }

    public void setInvnameProv(String invnameProv) {
        this.invnameProv = invnameProv;
    }

    public String getInvdescProv() {
        return invdescProv;
    }

    public void setInvdescProv(String invdescProv) {
        this.invdescProv = invdescProv;
    }

    public String getInvinputUser() {
        return invinputUser;
    }

    public void setInvinputUser(String invinputUser) {
        this.invinputUser = invinputUser;
    }

    public Date getInvinputDate() {
        return invinputDate;
    }

    public void setInvinputDate(Date invinputDate) {
        this.invinputDate = invinputDate;
    }

    public CoreStatusrecord getInvstatusProv() {
        return invstatusProv;
    }

    public void setInvstatusProv(CoreStatusrecord invstatusProv) {
        this.invstatusProv = invstatusProv;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (invidProv != null ? invidProv.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof InvClsprovider)) {
            return false;
        }
        InvClsprovider other = (InvClsprovider) object;
        if ((this.invidProv == null && other.invidProv != null) || (this.invidProv != null && !this.invidProv.equals(other.invidProv))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "inventory.modul.pojo.InvClsprovider[ invidProv=" + invidProv + " ]";
    }
    
}
