/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.modul.pojo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ronal
 */
@Entity
@Table(name = "inv_clsstageitems", catalog = "sidb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InvClsstageitems.findAll", query = "SELECT i FROM InvClsstageitems i")
    , @NamedQuery(name = "InvClsstageitems.findByInvidclsstageItems", query = "SELECT i FROM InvClsstageitems i WHERE i.invidclsstageItems = :invidclsstageItems")
    , @NamedQuery(name = "InvClsstageitems.findByInvnameclsstageItems", query = "SELECT i FROM InvClsstageitems i WHERE i.invnameclsstageItems = :invnameclsstageItems")
    , @NamedQuery(name = "InvClsstageitems.findByInvdescclsstageItems", query = "SELECT i FROM InvClsstageitems i WHERE i.invdescclsstageItems = :invdescclsstageItems")
    , @NamedQuery(name = "InvClsstageitems.findByInvinputUser", query = "SELECT i FROM InvClsstageitems i WHERE i.invinputUser = :invinputUser")
    , @NamedQuery(name = "InvClsstageitems.findByInvinputDate", query = "SELECT i FROM InvClsstageitems i WHERE i.invinputDate = :invinputDate")})
public class InvClsstageitems implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "inv_idclsstageItems")
    private Integer invidclsstageItems;
    @Size(max = 120)
    @Column(name = "inv_nameclsstageItems")
    private String invnameclsstageItems;
    @Size(max = 120)
    @Column(name = "inv_descclsstageItems")
    private String invdescclsstageItems;
    @Size(max = 120)
    @Column(name = "inv_inputUser")
    private String invinputUser;
    @Column(name = "inv_inputDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date invinputDate;
    @JoinColumn(name = "inv_statusstageItems", referencedColumnName = "core_idstatus")
    @ManyToOne(fetch = FetchType.EAGER)
    private CoreStatusrecord invstatusstageItems;

    public InvClsstageitems() {
    }

    public InvClsstageitems(Integer invidclsstageItems) {
        this.invidclsstageItems = invidclsstageItems;
    }

    public Integer getInvidclsstageItems() {
        return invidclsstageItems;
    }

    public void setInvidclsstageItems(Integer invidclsstageItems) {
        this.invidclsstageItems = invidclsstageItems;
    }

    public String getInvnameclsstageItems() {
        return invnameclsstageItems;
    }

    public void setInvnameclsstageItems(String invnameclsstageItems) {
        this.invnameclsstageItems = invnameclsstageItems;
    }

    public String getInvdescclsstageItems() {
        return invdescclsstageItems;
    }

    public void setInvdescclsstageItems(String invdescclsstageItems) {
        this.invdescclsstageItems = invdescclsstageItems;
    }

    public String getInvinputUser() {
        return invinputUser;
    }

    public void setInvinputUser(String invinputUser) {
        this.invinputUser = invinputUser;
    }

    public Date getInvinputDate() {
        return invinputDate;
    }

    public void setInvinputDate(Date invinputDate) {
        this.invinputDate = invinputDate;
    }

    public CoreStatusrecord getInvstatusstageItems() {
        return invstatusstageItems;
    }

    public void setInvstatusstageItems(CoreStatusrecord invstatusstageItems) {
        this.invstatusstageItems = invstatusstageItems;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (invidclsstageItems != null ? invidclsstageItems.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof InvClsstageitems)) {
            return false;
        }
        InvClsstageitems other = (InvClsstageitems) object;
        if ((this.invidclsstageItems == null && other.invidclsstageItems != null) || (this.invidclsstageItems != null && !this.invidclsstageItems.equals(other.invidclsstageItems))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "inventory.modul.pojo.InvClsstageitems[ invidclsstageItems=" + invidclsstageItems + " ]";
    }
    
}
