/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.modul.pojo;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ronal
 */
@Entity
@Table(name = "core_statusrecord", catalog = "sidb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CoreStatusrecord.findAll", query = "SELECT c FROM CoreStatusrecord c")
    , @NamedQuery(name = "CoreStatusrecord.findByCoreIdstatus", query = "SELECT c FROM CoreStatusrecord c WHERE c.coreIdstatus = :coreIdstatus")
    , @NamedQuery(name = "CoreStatusrecord.findByCoreDescriptionstatus", query = "SELECT c FROM CoreStatusrecord c WHERE c.coreDescriptionstatus = :coreDescriptionstatus")
    , @NamedQuery(name = "CoreStatusrecord.findByCoreinputUser", query = "SELECT c FROM CoreStatusrecord c WHERE c.coreinputUser = :coreinputUser")
    , @NamedQuery(name = "CoreStatusrecord.findByCoreinputDate", query = "SELECT c FROM CoreStatusrecord c WHERE c.coreinputDate = :coreinputDate")})
public class CoreStatusrecord implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "core_idstatus")
    private Integer coreIdstatus;
    @Size(max = 100)
    @Column(name = "core_descriptionstatus")
    private String coreDescriptionstatus;
    @Size(max = 120)
    @Column(name = "core_inputUser")
    private String coreinputUser;
    @Column(name = "core_inputDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date coreinputDate;
    @OneToMany(mappedBy = "invstatusstageItems", fetch = FetchType.EAGER)
    private Collection<InvClsstageitems> invClsstageitemsCollection;
    @OneToMany(mappedBy = "corestatusCategory", fetch = FetchType.EAGER)
    private Collection<CoreCategoryrecord> coreCategoryrecordCollection;
    @OneToMany(mappedBy = "invstatusProv", fetch = FetchType.EAGER)
    private Collection<InvClsprovider> invClsproviderCollection;
    @OneToMany(mappedBy = "invstatusWarehs", fetch = FetchType.EAGER)
    private Collection<InvClswarehouse> invClswarehouseCollection;

    public CoreStatusrecord() {
    }

    public CoreStatusrecord(Integer coreIdstatus) {
        this.coreIdstatus = coreIdstatus;
    }

    public Integer getCoreIdstatus() {
        return coreIdstatus;
    }

    public void setCoreIdstatus(Integer coreIdstatus) {
        this.coreIdstatus = coreIdstatus;
    }

    public String getCoreDescriptionstatus() {
        return coreDescriptionstatus;
    }

    public void setCoreDescriptionstatus(String coreDescriptionstatus) {
        this.coreDescriptionstatus = coreDescriptionstatus;
    }

    public String getCoreinputUser() {
        return coreinputUser;
    }

    public void setCoreinputUser(String coreinputUser) {
        this.coreinputUser = coreinputUser;
    }

    public Date getCoreinputDate() {
        return coreinputDate;
    }

    public void setCoreinputDate(Date coreinputDate) {
        this.coreinputDate = coreinputDate;
    }

    @XmlTransient
    public Collection<InvClsstageitems> getInvClsstageitemsCollection() {
        return invClsstageitemsCollection;
    }

    public void setInvClsstageitemsCollection(Collection<InvClsstageitems> invClsstageitemsCollection) {
        this.invClsstageitemsCollection = invClsstageitemsCollection;
    }

    @XmlTransient
    public Collection<CoreCategoryrecord> getCoreCategoryrecordCollection() {
        return coreCategoryrecordCollection;
    }

    public void setCoreCategoryrecordCollection(Collection<CoreCategoryrecord> coreCategoryrecordCollection) {
        this.coreCategoryrecordCollection = coreCategoryrecordCollection;
    }

    @XmlTransient
    public Collection<InvClsprovider> getInvClsproviderCollection() {
        return invClsproviderCollection;
    }

    public void setInvClsproviderCollection(Collection<InvClsprovider> invClsproviderCollection) {
        this.invClsproviderCollection = invClsproviderCollection;
    }

    @XmlTransient
    public Collection<InvClswarehouse> getInvClswarehouseCollection() {
        return invClswarehouseCollection;
    }

    public void setInvClswarehouseCollection(Collection<InvClswarehouse> invClswarehouseCollection) {
        this.invClswarehouseCollection = invClswarehouseCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (coreIdstatus != null ? coreIdstatus.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CoreStatusrecord)) {
            return false;
        }
        CoreStatusrecord other = (CoreStatusrecord) object;
        if ((this.coreIdstatus == null && other.coreIdstatus != null) || (this.coreIdstatus != null && !this.coreIdstatus.equals(other.coreIdstatus))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "inventory.modul.pojo.CoreStatusrecord[ coreIdstatus=" + coreIdstatus + " ]";
    }
    
}
